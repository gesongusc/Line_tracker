#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
from gazebo_msgs.msg import ModelState, ModelStates


 
#Reçoit une matrice de distance (0-360 degrés, incrément de 1 degré)
